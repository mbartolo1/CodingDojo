public class BankTest{
    public static void main(String[] args){
        BankAccount b1 = new BankAccount();
        b1.depositMoney(120.11, "checking");
        b1.depositMoney(200.40, "savings");
        b1.displayAccountBalance();
        System.out.println(BankAccount.totalHoldings);
        b1.withdrawMoney(100,"checking");
        b1.withdrawMoney(20.10, "savings");
        b1.displayAccountBalance();
        System.out.println(BankAccount.totalHoldings);
    }
}