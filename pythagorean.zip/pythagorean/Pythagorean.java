import java.lang.Math;
public class Pythagorean{
    public void calculateHypotenuse(int legA, int legB){
        double squareRoot = Math.sqrt(legA* legA + legB * legB);
        System.out.println("Hypotenuse is: " + squareRoot);
    }
}
