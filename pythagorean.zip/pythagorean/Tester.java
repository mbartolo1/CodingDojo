public class Tester{
    public static void main(String[] args){
        Pythagorean calculator = new Pythagorean();
        calculator.calculateHypotenuse(5, 10);
    }
}