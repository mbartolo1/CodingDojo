public class Tester{
    public static void main(String[] args){
        FizzBuzz calculator =  new FizzBuzz();
        calculator.fizzBuzz(2);
    }
}