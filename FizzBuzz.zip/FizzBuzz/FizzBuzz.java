
public class FizzBuzz{
    public void fizzBuzz(int number){
        if(number%3 ==0 && number%5 == 0){
            System.out.println("fizzbuzz");
        }
        else if(number %3 == 0) {
            System.out.println("fizz");
        }else if(number %5 == 0){
            System.out.println("bizz");
        } else {
            System.out.println(number);
        }
        }
        
    }