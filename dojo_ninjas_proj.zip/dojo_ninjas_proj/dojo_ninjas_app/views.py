from django.shortcuts import render, redirect
from dojo_ninjas_app.models import *

def index(request):
    context={
        "dojos" : Dojo.objects.all(),
        #"all_the_ninjas_in_dojos" : Dojo.objects.filter(id="ninjas"),
        "ninjas" : Ninja.objects.all(),
    }
    return render(request,'index.html', context)

def newdojosandninjas(request):
    #context={
        #"newly_created_Dojo" : Dojo.objects.create(name = request.POST['name'], city = request.POST['city'], state = request.POST['state']),
        #"newly_created_Ninja" : Ninja.objects.create(first_name = request.POST['first_name'], last_name = request.POST['last_name'], dojo = request.POST['dojo'])

    #}
    potatoes = request.POST['dojo_id']
    dojo_id_number = Dojo.objects.get(id = potatoes)
    Ninja.objects.create(first_name = request.POST['first_name'], last_name = request.POST['last_name'], dojo = dojo_id_number)
    #return render(request, redirect ('/')) #context)
    return redirect('/')