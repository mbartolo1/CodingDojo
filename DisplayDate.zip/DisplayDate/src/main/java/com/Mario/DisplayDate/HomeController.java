package com.Mario.DisplayDate;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;

@Controller
public class HomeController {
	@RequestMapping("/")
	public String index() {
		return "Index.jsp";
	}
	@RequestMapping("/date")
	public String date() {
		new java.util.Date();
		return "date.jsp";
}
	@RequestMapping("/time")
	public String time() {
		return "time.jsp";
	}
}