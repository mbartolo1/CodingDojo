from django.urls import path
from . import views

urlpatterns = [
    path('', views.dashboard),
    path('shows/new', views.addshow),
    path('addshow', views.processshow),
    path('editshow/<int:id>', views.editshow),
    path('shows/<int:id>', views.printshow),
    path('delete/<int:id>', views.delete),
    path('update/<int:id>', views.update)
]