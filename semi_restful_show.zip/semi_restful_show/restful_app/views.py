from django.shortcuts import render, redirect
from .models import Shows

#def index(request):
    #context = {
        #"movies": Movies.objects.all()
    #}
    #return render(request, "index.html", context)

def dashboard(request):
    context = {
        "all_the_shows": Shows.objects.all()
    }
    return render(request,'index.html',context)

def addshow(request):
    
    return render(request, 'addshow.html')

def processshow(request):
    Shows.objects.create(
        title = request.POST['title'], 
        network= request.POST['network'], 
        release_date = request.POST['release_date'], 
        description = request.POST['description']
        )
    return redirect('/')

def editshow(request, id):
    potatoes = Shows.objects.get(id == id)
    context = {
        'potatoes' : potatoes
    }
    return render(request, 'editshow.html', context)

def printshow(request, id):
    Vcarrots = Shows.objects.get(id = id)
    context = {
        'carrots' : Vcarrots
    }
    return render(request, 'showinfo.html', context)

def delete(request, id):
    carrots = Shows.objects.get(id = id)
    carrots.delete()
    return redirect('/')

def update(request, id):
    Vcarrots = Shows.objects.filter(id=id).update(
        title = request.POST['title'],
        network = request.POST['network'],
        release_date = request.POST['release_date'],
        description = request.POST['description'],
    )
    
    return redirect('/')