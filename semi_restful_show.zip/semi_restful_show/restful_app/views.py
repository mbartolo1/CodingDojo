from django.shortcuts import render, redirect
from .models import Shows
from django.db import models
from django.contrib import messages
#def index(request):
    #context = {
        #"movies": Movies.objects.all()
    #}
    #return render(request, "index.html", context)

def dashboard(request):
    context = {
        "all_the_shows": Shows.objects.all()
    }
    return render(request,'index.html',context)

def addshow(request):
    
    return render(request, 'addshow.html')

def processshow(request):
    errors = Shows.objects.basic_validator(request.POST)
    if len(errors) > 0:
        for key, value in errors.items():
            messages.error(request, value)
            print(errors)
        return redirect('/shows/new')
    else:
        title = request.POST['title']
        network = request.POST['network']
        description = request.POST['description']

        Shows.objects.create(
            title = request.POST['title'], 
            network= request.POST['network'], 
            release_date = request.POST['release_date'], 
            description = request.POST['description']
            )
        return redirect('/')

def editshow(request, id):
    potatoes = Shows.objects.get(id = id)
    context = {
        'potatoes' : potatoes
    }
    return render(request, 'editshow.html', context)

def printshow(request, id):
    Vcarrots = Shows.objects.get(id = id)
    context = {
        'carrots' : Vcarrots
    }
    return render(request, 'displayshow.html', context)

def delete(request, id):
    carrots = Shows.objects.get(id = id)
    carrots.delete()
    return redirect('/')

def update(request, id):
    Vcarrots = Shows.objects.filter(id=id).update(
        title = request.POST['title'],
        network = request.POST['network'],
        release_date = request.POST['release_date'],
        description = request.POST['description'],
    )
    
    return redirect('/')

class ShowsManager(models.Manager):
    def basic_validator(self, postData):
        errors = {}
        if len(postData['title']) < 5:
            errors['title'] = "title should be at least 5 characters"
        if len(postData['network']) < 5:
            errors['network'] = "network should be longer than 5 characters"
        if len(postData['description']) < 2:
            errors['description'] = "description needs to be longer than 5 characters"
        return errors
