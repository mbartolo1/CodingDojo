package com.Mario.DojoSurvey;

import javax.servlet.http.HttpSession;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;

@Controller
public class HomeController {
	@RequestMapping("/")
	public String index() {
		return "index.jsp";
	}
	@RequestMapping(path="/submit", method=RequestMethod.POST)
	public String submit(@RequestParam String name, @RequestParam String location, @RequestParam String language, @RequestParam String comment, HttpSession sesh) {
		sesh.setAttribute("name", name);
		sesh.setAttribute("location", location);
		sesh.setAttribute("language", language);
		sesh.setAttribute("comment", comment);
		return "redirect:/results";
	}
	@RequestMapping("/results")
	public String results(HttpSession sesh, Model model) {
		String name = (String) sesh.getAttribute("name");
		String location = (String) sesh.getAttribute("location");
		String language = (String) sesh.getAttribute("language");
		String comment = (String) sesh.getAttribute("comment");
		model.addAttribute("name", name);
		model.addAttribute("location", location);
		model.addAttribute("language", language);
		model.addAttribute("comment", comment);
		return "results.jsp";
	}
}
