from django.urls import path
from . import views

urlpatterns = [
    path('', views.first_view),
    path('update', views.second_view),
]
