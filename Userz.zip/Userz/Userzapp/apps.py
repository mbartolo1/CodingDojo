from django.apps import AppConfig


class UserzappConfig(AppConfig):
    name = 'Userzapp'
