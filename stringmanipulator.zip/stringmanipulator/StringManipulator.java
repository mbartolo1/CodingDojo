public class StringManipulator{
    public String trimAndConcat(String str1, String str2){
        return str1.trim()+str2.trim();
    }
    public Integer getIndexOrNull(String str1, char letter){
        int a = str1.indexOf(letter);
        if(a < 0){
            return null;
        }else{
            return a;
        }
    }
    public Integer getIndexOrNull(String word,String subString){
        int a1 = word.indexOf(subString);
        if(a1 < 0){
            return null;
        } else{
            return a1;
        }
    }
    public String concatSubstring(String str1, int number1, int number2, String str2){
        return str1.substring(number1, number2)+str2;
    }
}
