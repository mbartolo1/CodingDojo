public class StringManipulatorTest {
    public static void main(String[] args){
        StringManipulator manipulator = new StringManipulator();
        String string = manipulator.trimAndConcat("   hello   ","   world   ");
        System.out.println(string);

        char letter = 'o';
        Integer a = manipulator.getIndexOrNull("coding", 'o');
        Integer b = manipulator.getIndexOrNull("hello world", 'o');
        Integer c = manipulator.getIndexOrNull("Hi", 'o');
        System.out.println(a); // 1
        System.out.println(b); // 4
        System.out.println(c); // null

        String word = "Hello";
        String subString = "llo";
        String notSubString = "world";
        Integer a1 = manipulator.getIndexOrNull(word, subString);
        Integer b1 = manipulator.getIndexOrNull(word, notSubString);
        System.out.println(a1); // 2
        System.out.println(b1); // null
        
        String word1 = manipulator.concatSubstring("Hello", 1, 2, "world");
        System.out.println(word1); // eworld
    }
}