
import List from './components/List';
function App() {
  return (
    <div className="App">
      <List />

    </div>
  );
}

export default App;
