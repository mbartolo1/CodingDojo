import React, { Component } from 'react';
import Name from './Name';

class List extends Component{
    constructor(props){
        super(props);
    }
    render(){
        return(
            <>
            <Name name = {"Doe, Jane"} hair = {"Black"} age ={88}/>
            <Name name = {"Smith, John"} hair = {"Brown"} age ={88}/>
            <Name name = {"Fillmore, Millard"} hair = {"Brown"} age={50} />
            <Name name = {"Smith, Maria"} hair = {"Brown"} age ={62}/>
            </>
            
            
        )
    }
}
export default List;