public class GorillaTest{
    public static void main(String[] args){
        Gorilla a = new Gorilla();
        a.throwSomething();
        a.eatBanana();
        a.climb();
        a.displayEnergy();
    }
}