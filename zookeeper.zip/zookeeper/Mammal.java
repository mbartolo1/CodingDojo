public class Mammal{
    int energylevel = 100;
    public int displayEnergy(){
        System.out.println("Current Energy level:" + energylevel);
        return energylevel;
    }
    // public Mammal(int energylevel){
    //     this.energylevel = energylevel;
    // }
}