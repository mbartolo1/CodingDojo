public class Gorilla extends Mammal{
    // public Gorilla(int energylevel){
    //     super(energylevel);
    // }
    public void throwSomething(){
        System.out.println("throwing");
        energylevel -=5;
    }
    public void eatBanana(){
        System.out.println("mmm yummy bananana, lifes good");
        energylevel += 10;
    }
    public void climb(){
        System.out.println("climbin' trees");
        energylevel -=10;
    }
}