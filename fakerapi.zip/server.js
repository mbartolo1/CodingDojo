const { response } = require("express");
const express = require("express");
const faker = require("faker");
const app = express();

class User{
    constructor(){
        // this.id = faker.commerce.id();
        this.firstName = faker.name.firstName();
        this.lastName = faker.name.lastName();
        this.phoneNumber = faker.phone.phoneNumber();
        this.email = faker.name.title();
        this.password = faker.name.jobArea();
    }
}
console.log(new User());
class Company{
    constructor(){
        this.name = faker.name.firstName();
        this.address = faker.address.streetAddress();
    }
}

app.use(express.json());
app.get("/companies/new", (req, res)=>{
    console.log(request.params);
    response.send("this is how we grab params out of the url");
})
app.get("/user/new", (req, res)=>{
    res.json(new User());
})

app.get("/", (req, res) =>{
    res.json(new Company());
})
app.get("/user/company", (req, res)=>{
    res.json(new Company());
    res.json(new User());
})
app.post("/user/new", (req, res)=>{
    console.log(req.body);
    res.send("this is how we grab data out of a form post");
})
app.listen(8000, () =>{
    console.log("running on 8000");
})
