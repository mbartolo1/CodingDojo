from django.apps import AppConfig


class FirstapppConfig(AppConfig):
    name = 'firstappp'
