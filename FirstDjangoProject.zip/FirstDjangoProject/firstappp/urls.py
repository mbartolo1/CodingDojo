from django.urls import path
from . import views



urlpatterns = [
    path('', views.index),
    path('blogs', views.blogs),
    path('blogs/new', views.new),
    path('blogs/create', views.index),
    path('blogs/<number>', views.show),
    path('blogs/<number>/edit', views.edit),
    path('blogs/<number>/delete', views.destroy),
]