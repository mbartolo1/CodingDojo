from django.apps import AppConfig


class LoginandregappConfig(AppConfig):
    name = 'loginandregapp'
