from django.db import models
import re
class UserManager(models.Manager):
    def basic_validator(self, postData):
        errors = {}
        EMAil_REGEX = re.compile(r'^[a-zA-z0-9.+_-]+@[a-zA-z0-9._-]+\.[a-zA-Z]+$')
        if not EMAil_REGEX.match(postData['email']):
            errors['email'] = "please insert valid email address!"
            return errors 
        if len(postData['first_name']) < 2:
            errors['first_name'] = "first name must be at least 2 characters long"
        if len(postData['last_name']) < 2:
            errors['last_name'] = "last name  must be at least 2 characters long"
        if postData['password'] != postData['confirm_password']:
            errors['password'] = "passwords do not match"
        
        return errors 

class User(models.Model):
    first_name = models.CharField(max_length=255)
    last_name = models.CharField(max_length=255)
    email = models.EmailField()
    password = models.CharField(max_length=20)
    updated_at = models.DateTimeField(auto_now=True)
    created_at = models.DateTimeField(auto_now_add=True)
    objects = UserManager()


