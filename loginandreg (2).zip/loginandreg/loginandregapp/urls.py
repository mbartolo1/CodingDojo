from django.urls import path
from . import views

urlpatterns = [
    path('', views.index),
    path('newuser', views.newuser),
    path('login/<int:newuser_id>', views.congrats),
    path('register', views.newuser),
    path('login', views.login),
    path('logout_user', views.logout_user),

]