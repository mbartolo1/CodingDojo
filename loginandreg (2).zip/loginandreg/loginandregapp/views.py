from django.shortcuts import render, redirect
from .models import User
from django.contrib import messages
import bcrypt 
from django.contrib.auth import authenticate, login, logout

def index(request):
    return render(request,'index.html')

def newuser(request):
    errors = User.objects.basic_validator(request.POST)
    if len(errors)>0:
        for key,value in errors.items():
            messages.error(request, value)
        return redirect('/')
    else:
        pw_hash = bcrypt.hashpw(request.POST['password'].encode(), bcrypt.gensalt()).decode()
        newuser = User.objects.create(
        first_name = request.POST['first_name'],
        last_name = request.POST['last_name'],
        email = request.POST['email'],
        password = pw_hash
    )
    return redirect(f'login/{newuser.id}',)

def congrats(request, newuser_id):
    user = User.objects.get(id = newuser_id)
    context = {
        'user' : user
    }
    return render(request,'loggedin.html', context)

def login(request):
    user = User.objects.filter(email = request.POST['email'])
    if user:
        logged_user = user[0]
        if bcrypt.checkpw(request.POST['password'].encode(), logged_user.password.encode()):
            request.session['userid'] = logged_user.id
            return redirect(f'/login/{logged_user.id}')
    return redirect('/')

def logout_user(request):
    logout(request)
    return redirect('/')