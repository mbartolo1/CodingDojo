from django.shortcuts import render
#def first_view(request):
    context = {
        'some_data': "hello"
    }
    return render(request, "users_app/index.html", context)

#def second_view(request):
        context = {
            'create_user': User.objects.create()
        }
        return render(request, "index.html")