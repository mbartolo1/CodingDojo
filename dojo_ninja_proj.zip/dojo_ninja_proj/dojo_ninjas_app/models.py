from django.db import models

class Dojo(models.Model):
    name = models.CharField(max_length=20)
    city = models.CharField(max_length=20)
    state = models.CharField(max_length=20)
    desc = models.CharField(max_length=250)
    updated_at = models.DateField(auto_now_add=True)
    created_at = models.DateField(auto_now_add = True)


class Ninja(models.Model):
    first_name = models.CharField(max_length=20)
    last_name = models.CharField(max_length=20)
    dojo = models.ForeignKey(Dojo, related_name="ninjas", on_delete= models.CASCADE)
    created_at = models.DateField(auto_now_add=True)
    updated_at = models.DateField(auto_now = True)


