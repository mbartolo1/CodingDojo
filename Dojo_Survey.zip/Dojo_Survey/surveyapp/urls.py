from django.urls import path, include
from . import views

urlpatterns = [
    path('', views.index),
    path('results', views.create_user)
]