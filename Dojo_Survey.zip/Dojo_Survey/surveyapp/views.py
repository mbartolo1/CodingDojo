from django.shortcuts import render

def index(request):
    return render (request,"index.html")

def create_user(request):
    print("Got Post Info....")
    context = {
        'name_on_template' : request.POST['name'],
        'location_on_template' : request.POST['location'],
        'language_on_template' : request.POST['comment']
    }
    return render(request,"show.html",context)