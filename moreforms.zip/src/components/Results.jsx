import React from 'react';

const Results = props =>{
    // const {firstname, lastname, email,password, confirmPassword} = props.data;
    return(
        <div>
            {/* <p>First Name: {firstname}</p>
            <p>Last Name: {lastname}</p>
            <p>email: {email}</p>
            <p>password: {password}</p>
            <p>confirmpassword: {confirmPassword}</p> */}
        </div>
    );
};
export default Results;