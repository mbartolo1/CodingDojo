import React from 'react';

const HookForm = (props) => {
    const {firstname, setFirstName} = props;
        const{lastname, setLastName} = props;
        const{email, setEmail} =props;
        const{password, setPassword}= props;
        const{confirmPassword, setConfirmPassword} = props;
        const {firstError, setFirstError}= props;
        const{lastError, setLastError}= props;
        const{emailError, setEmailError}=props;

        const handleFirstName = (e) =>{
            console.log(firstname);
            setFirstName(e.target.value);
            if(e.target.value.length < 1){
                setFirstError("first name cant be empty");
            } else if(e.target.value.length < 2){
                setFirstError("first name must be at least 2 characters long");
            }
        }

            const handleLastName = (e) =>{
                console.log(lastname);
                setLastName(e.target.value);
                if(e.target.value.length < 1){
                    setLastError("last name cant be empty");
                }else if(e.target.value.length < 2){
                    setLastError("last name must be at least 2 characters long");
                }
            }
            
            const handleEmail =(e) =>{
                console.log(email);
                setEmail(e.target.value);
                if(e.target.value.length < 1){
                    setEmailError("email cant be empty");
                }else if(e.target.value.length < 5){
                    setEmailError("email must be at least 5 characters long");
                }
            }
            
    return(
        <form onSubmit={ (e) => e.preventDefault()}>
            <div>
                <label>First name:</label>
                <input type = "text" value={firstname} onChange= {e => handleFirstName (e) } />{
                    firstError?
                    <p style={{color:'red'}}>{firstError}</p>:
                    ''
                }
            </div>
            <div>
                <label>Last Name:</label>
                <input type="text" value={lastname} onChange={e => handleLastName (e) }/>{
                    lastError?
                    <p style={{color:"red"}}>{lastError}</p>:
                    ''
                }
            </div>
            <div>
                <label>Email Address:</label>
                <input type="text" value={email} onChange = {e => handleEmail(e)}/>{
                    emailError?
                    <p style={{color:"red"}}>{emailError}</p>:
                    ''
                }
            </div>
            <div>
                <label>Password:</label>
                <input type="text" value={password} onChange={e => setPassword(e.target.value)}/>
            </div>
            <div>
                <label>confirm Password</label>
                <input type="text" value={confirmPassword} onChange={e => setConfirmPassword(e.target.value)}/>
            </div>
            <input type="submit" value="Create User" />
        </form>
    );
};

export default HookForm;