import React, {useState} from "react";
import './App.css';
import HookForm from "./components/HookForm";
import Results from "./components/Results";

function App() {
  const [firstname, setFirstName] = useState("");
    const[lastname, setLastName] = useState("");
    const[email, setEmail] =useState("");
    const[password, setPassword]= useState("");
    const[confirmPassword, setConfirmPassword] = useState("");
    const [firstError, setFirstError]= useState("");
    const[lastError, setLastError] =useState("");
    const[emailError, setEmailError]=useState("");
    

  return (

    <div className="App">
      <HookForm firstname = {firstname}
                setFirstName={setFirstName} 
                lastname = {lastname} 
                setLastName={setLastName}
                email={email} 
                setEmail={setEmail} 
                password ={password}
                setPassword ={setPassword}
                confirmPassword = {confirmPassword} 
                setConfirmPassword={setConfirmPassword} 
                firstError={firstError} 
                setFirstError={setFirstError}
                lastError={lastError}
                setLastError={setLastError}
                emailError ={emailError}
                setEmailError={setEmailError}
                />
      <Results />
    </div>
  );
}

export default App;
