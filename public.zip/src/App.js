import logo from './logo.svg';
import './App.css';

function App() {
  return (
    <div className="App">
        <h1>Hello Dojo</h1>
        <h2>Things i have to do:</h2>
          <li>learn react</li>
          <li>Climb Mt.Everest</li>
          <li>Run a Marathon</li>
          <li>Feed the Dogs</li>
    </div>
  );
}

export default App;
