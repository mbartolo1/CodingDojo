import React, {useState} from 'react';

const Box = ({box}) =>{
    return(
        <div>
            <span style = {{'background-color':box.color, height: '200px', width:'200px', display:'inline-block'}}>This is the {box.color} box</span>
        </div>
    )
}
export default Box;