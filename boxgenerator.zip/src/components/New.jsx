import {useState} from 'react';

const New = ({createBox}) =>{
    const[newColor, setNewColor]=useState("");
    const [error, setError] = useState("");
    const submitColor =(event) => {
        event.preventDefault();

        const errs = false;
        if(newColor.length <3 ){
            setError("must add a longer color!");
            errs = true;
        }
        if(!errs){
            setError(null);
            console.log(newColor);
            createBox({color: newColor});

        }
    }
    return(
        <>
            what the user is typing: {newColor}
            {error}
            <form onSubmit={submitColor}>
                <input type="color" value={newColor} onChange={e => setNewColor(e.target.value)} />
                <input type="submit" value="Create a new color!" />
            </form>
            </>
    )



}
export default New;