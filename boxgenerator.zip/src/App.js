import React, {useState} from 'react';
import Boxes from './components/Boxes';
import './App.css';
import Box from './components/Box';
import New from './components/New'
function App() {
const [boxes, setBoxes] = useState([
  {color:"blue"},
  {color:"red"},
  {color:"green"},
  {color: "yellow"},
])

  const createBox = (box) =>{
    setBoxes([...boxes, box])
  };
  

  return (
    <div className="App">
      <Boxes boxes = {boxes}/>
      <New   createBox={createBox}/>
    </div>
  );
}

export default App;
