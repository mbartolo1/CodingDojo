from django.shortcuts import render, HttpResponse
import random
def index(request):
    request.session['randomnumb'] = random.randint(1, 100)
    return render(request,'game.html')

def guess(request):
    rettext = ""
    mynumber = int(request.POST['number'])
    if mynumber > request.session['randomnumb']:
        rettext = "too high"
    elif mynumber < request.session['randomnumb']:
        rettext = "too low"
    elif mynumber == request.session['randomnumb']:
        rettext = "correct"
    context = {
        'msg': rettext
    }
    return render(request,'game.html', context)